This is an database sunject project, a simple crud usnig postgresql and nodejs
